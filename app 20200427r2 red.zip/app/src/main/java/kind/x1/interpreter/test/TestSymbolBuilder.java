package kind.x1.interpreter.test;

import kind.x1.interpreter.*;
import kind.x1.interpreter.symbols.*;

public class TestSymbolBuilder extends SymbolBuilder
{
    Symbol test;
    
    public TestSymbolBuilder (Symbol t) { test = t; }
    
    public Symbol build() { return test; }
}
