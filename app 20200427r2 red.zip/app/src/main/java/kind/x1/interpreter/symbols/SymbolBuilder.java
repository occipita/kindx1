package kind.x1.interpreter.symbols;

import kind.x1.ast.*;
import kind.x1.*;
import kind.x1.misc.SID;
import kind.x1.interpreter.executables.*;
import kind.x1.interpreter.types.TypeBuilder;
import kind.x1.interpreter.types.ConstraintBuilder;

import java.util.List;

public class SymbolBuilder extends DefnVisitor
{
    private Symbol building;
    private Factory<ExecutableBuilder> executableBuilderFactory = ExecutableBuilder.FACTORY;
    private Factory<TypeBuilder> typeBuilderFactory = TypeBuilder.FACTORY;
    private Factory<ConstraintBuilder> constraintBuilderFactory = ConstraintBuilder.FACTORY;
    private SymbolBuilder childBuilder;
    private FunctionBuilder functionBuilder;
    
    public Symbol build() { return building; }
    public void setExecutableBuilderFactory (Factory<ExecutableBuilder> f) { executableBuilderFactory = f; }
    public void setTypeBuilderFactory (Factory<TypeBuilder> f) { typeBuilderFactory = f; }
    
    public DefnVisitor property (String name, Optional<Type> type) //FIXME should be TypeVisitor.Visitable (or perhaps method to ret a visitor)
    {
        TypeBuilder tb = typeBuilderFactory.create();
        type.get().visit(tb);
        building = new PropertySymbol(name, tb.build()); 
        return this; 
    }
    public void propertyAccessor (Defn.AccessorType type, StmtVisitor.Visitable statement) 
    {
        ExecutableBuilder eb = executableBuilderFactory.create();
        statement.visit (eb);
        Executable e = eb.build();
        ((PropertySymbol)building).addAccessor (type, e); 
    }
    
    public DefnVisitor beginInterface (String name) { 
        building = new InterfaceSymbol(name);
        return this; 
    }
    public void interfaceParameter (String name) { ((InterfaceSymbol)building).getParameters().add(name); }
    public void interfaceConstraint (Type.Constraint c) { 
        ConstraintBuilder b = constraintBuilderFactory.create();
        c.visit(b);
        ((InterfaceSymbol)building).getParameterConstraints().add(b.build());
    }    
    public void interfaceSuperinterface (Type t) {
        TypeBuilder b = typeBuilderFactory.create();
        t.visit(b);
        ((InterfaceSymbol)building).getSuperinterfaces().add(b.build());        
    }
    public void interfacePlaceholder (List<String> names) { ((InterfaceSymbol)building).getPlaceholders().addAll(names); }
    public DefnVisitor visitInterfaceMember () { return null; }
    public void endInterface () { }
    
    public DefnVisitor beginFunction (String name) { 
        functionBuilder = new FunctionBuilder (name);
        return functionBuilder; 
    }
    public DefnVisitor beginOperatorFunction (String symbol) { return null; }
    public void endFunction () { building = functionBuilder.build(); }


    public static final Factory<SymbolBuilder> FACTORY = new Factory<SymbolBuilder>() {
        public SymbolBuilder create() { return new SymbolBuilder(); } 
    };
    
    
}
