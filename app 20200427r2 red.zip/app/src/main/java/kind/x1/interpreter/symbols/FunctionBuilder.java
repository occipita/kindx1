package kind.x1.interpreter.symbols;

import kind.x1.ast.DefnVisitor;
import kind.x1.ast.PatternVisitor;
import kind.x1.ast.StmtVisitor;
import kind.x1.ast.TypeVisitor;
import kind.x1.*;
import kind.x1.misc.SID;
import java.util.List;
import java.util.ArrayList;

public class FunctionBuilder extends DefnVisitor
{
    private FunctionSymbol fn;
    private Factory<TypeBuilder> typeBuilderFactory = TypeBuilder.FACTORY;
    
    
    
    public void beginAbstractBody () { }
    public void beginImplementationBody () { }
    public void parameterPattern (PatternVisitor.Visitable pattern) { }
    public void returnType (TypeVisitor.Visitable type) { 
        TypeBuilder tb = typeBuilderFactory.create();
        type.visit(tb);
        fn.setReturnType(tb.build());
    }
    public void bodyImplementation (StmtVisitor.Visitable stmt) { }
    public void endFunctionBody () { }
}
