package kind.x1.interpreter.symbols;

import kind.x1.interpreter.types.Type;

public class FunctionSymbol extends Symbol
{
    Type returnType;
    
    public FunctionSymbol (String name) { super(name); }
    public boolean isAbstract() { return false; }
    public Type getReturnType () { return returnType; }
    public void setReturnType (Type t) { returnType = t; }
}
