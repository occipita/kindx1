package kind.x1.interpreter.types;

import kind.x1.misc.SID;

public class TypeReference implements Type 
{
    private final SID sid;
    
    public TypeReference (SID s) { sid = s; }
    public String getName() { return sid.toString(); }
    public boolean isFullyResolved () { return false; }   
}
