package kind.x1.interpreter;

import kind.x1.ast.*;
import kind.x1.*;
import kind.x1.misc.SID;
import java.util.List;

public class ModuleBuilder extends ModVisitor
{
    ModuleResolver moduleResolver = ModuleResolver.NULL;
    DiagnosticProducer diagnosticProducer = DiagnosticProducer.CONSOLE;
    
    Module building = new Module();
    public Module build()
    {
        return building;
    }
    
    public void setModuleResolver (ModuleResolver r) { moduleResolver = r; }
    public void setDiagnosticProducer (DiagnosticProducer d) { diagnosticProducer = d; }
    
    public void importWild (SID base, Optional<SID> as) { }
    public void importSpecified (SID base, List<String> ids, Optional<SID> as) 
    { 
        Optional<Module> module = moduleResolver.findModule(base);
        if (!module.isPresent()) { 
            error ("Module " + base + " not found");
            return;
        }
        Scope target = building.getLocalScope();
        for (String id : ids) {
            Optional<Symbol> sym = module.get().getExportedSymbol (id);
            if (sym.isPresent()) {
                target.addSymbol (sym.get());
            }
            else {
                error ("Symbol "+base+"::"+id+" not found");
            }
        }
    }
    public void export (String symbol) { }
    public void define (DefnVisitor.Visitable definition) { }
    public void defineAndExport (DefnVisitor.Visitable definition) { }

    private void error (String msg)
    {
        diagnosticProducer.error (msg);
    }
}
