package kind.x1.interpreter;

public interface Symbol 
{
    String getName ();
}
