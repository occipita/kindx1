package kind.x1.interpreter;

import kind.x1.Optional;
import java.util.HashSet;

public class Module 
{
    private final Scope localScope = new Scope();
    private final HashSet<String> exports = new HashSet<>();
    
    public Scope getLocalScope() { return localScope; }
    public void export (String name) { exports.add(name); }
    public Optional<Symbol> getExportedSymbol(String id)
    {
        if (!exports.contains(id)) return Optional.empty();
        return localScope.getSymbol(id);
    }
}
