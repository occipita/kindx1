package kind.x1.interpreter.test;

import kind.x1.*;
import kind.x1.ast.*;
import kind.x1.misc.*;
import kind.x1.interpreter.*;
import java.util.List;
import java.util.Collections;

public class ModuleBuilderTest extends Assertions implements Runnable
{
    public void run()
    {
        importSpecified();
        cannotImportUnexportedSymbol();
    }
    public void importSpecified()
    {
        ModuleBuilder b = new ModuleBuilder();
        Module testModule = new Module();
        Symbol testSymbol = new TestSymbol ("testSymbol");
        testModule.getLocalScope().addSymbol (testSymbol);
        testModule.export ("testSymbol");
        b.setModuleResolver (new StaticModuleResolver ().add(SID.from("test::module"), testModule));
        b.importSpecified (SID.from("test::module"), Collections.singletonList("testSymbol"), Optional.empty());
        Module built = b.build();
        
        assertEqual ("importSpecified: testSymbol should be defined in local scope", 
            built.getLocalScope().getSymbol ("testSymbol").orElse(null),
            testSymbol);
    }
    public void cannotImportUnexportedSymbol()
    {
        ModuleBuilder b = new ModuleBuilder();
        TestDiagnosticProducer tdp = new TestDiagnosticProducer();
        b.setDiagnosticProducer (tdp);
        Module testModule = new Module();
        Symbol testSymbol = new TestSymbol ("testSymbol");
        testModule.getLocalScope().addSymbol (testSymbol);
        // not done: testModule.export ("testSymbol");
        b.setModuleResolver (new StaticModuleResolver ().add(SID.from("test::module"), testModule));
        b.importSpecified (SID.from("test::module"), Collections.singletonList("testSymbol"), Optional.empty());
        Module built = b.build();
        
        assertEqual ("cannotImportUnexportedSymbol: testSymbol should not be defined in local scope", 
            built.getLocalScope().getSymbol ("testSymbol"),
            Optional.empty());
        assertEqual ("cannotImportUnexportedSymbol: should have produced an error message",
            tdp.getErrors().size(),
            1);
    }
}
