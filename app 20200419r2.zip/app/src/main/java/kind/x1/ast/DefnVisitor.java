package kind.x1.ast;

public class DefnVisitor 
{
    public interface Visitable { void visit (DefnVisitor visitor); }
}
