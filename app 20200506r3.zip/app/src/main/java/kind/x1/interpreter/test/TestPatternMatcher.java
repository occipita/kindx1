package kind.x1.interpreter.test;

import kind.x1.interpreter.patterns.PatternMatcher;

public class TestPatternMatcher implements PatternMatcher
{
    
}
