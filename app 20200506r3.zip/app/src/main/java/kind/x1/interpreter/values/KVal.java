package kind.x1.interpreter.values;

public interface KVal 
{

}
