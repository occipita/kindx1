package kind.x1.interpreter.test;

public class TestEvaluatable implements kind.x1.interpreter.executables.Evaluatable
{

}
