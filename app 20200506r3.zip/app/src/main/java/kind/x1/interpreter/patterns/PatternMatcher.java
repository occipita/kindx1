package kind.x1.interpreter.patterns;

public interface PatternMatcher 
{
    public static final PatternMatcher ACCEPT = new PatternMatcher() {
    };
    public static final PatternMatcher REJECT = new PatternMatcher() {
    };
    
}
