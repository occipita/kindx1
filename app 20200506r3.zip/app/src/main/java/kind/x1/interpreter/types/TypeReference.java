package kind.x1.interpreter.types;

import kind.x1.misc.SID;

public class TypeReference implements Type 
{
    private final SID sid;
    
    public TypeReference (SID s) { sid = s; }
    public String getName() { return sid.toString(); }
    public boolean isFullyResolved () { return false; }   
    
    public boolean equals (Object o)
    {
        if (o.getClass() != getClass())return false;
        TypeReference other=(TypeReference) o;
        return sid.equals(other.sid);
    }
    public int hashCode () { return sid.hashCode(); }
    public String toString() { return "TypeReference<"+sid+">"; }
    
}
