package kind.x1.interpreter.symbols;

import kind.x1.interpreter.types.Type;
import kind.x1.interpreter.patterns.PatternMatcher;
import kind.x1.interpreter.executables.Executable;
import kind.x1.Optional;

import java.util.List;
import java.util.ArrayList;

public class FunctionSymbol extends Symbol
{
    private Type returnType;
    private List<PatternMatcher> parameters = new ArrayList<>();
    private Optional<Executable> executable = Optional.empty();
    private boolean isAbstract;
    
    public FunctionSymbol (String name) { super(name); }
    public boolean isAbstract() { return isAbstract; }
    public void setAbstract (boolean v) { isAbstract = v; }
    public Type getReturnType () { return returnType; }
    public void setReturnType (Type t) { returnType = t; }
    public List<PatternMatcher> getParameters() { return parameters; }
    public Optional<Executable> getExecutable() { return executable; }
    public void setExecutable(Optional<Executable> e) { executable = e; }
}
