package kind.x1.interpreter;

import kind.x1.misc.SID;
import kind.x1.Optional;

public interface ModuleResolver 
{
    Optional<Module> findModule (SID name);
    
    public static final ModuleResolver NULL = new ModuleResolver() {
        public Optional<Module> findModule (SID name) { return Optional.empty(); }
    };
}
