package tools;

import java.lang.reflect.*;

public class Methods {

  public static void main(String[] args) {
    Class<?> c = java.util.Collections.class;
    
    System.out.println (c);
    for (Method m : c.getDeclaredMethods())
    {
        System.out.println (m);
    }
    for (Field f : c.getDeclaredFields())
    {
        System.out.println (f);
    }
  }

}
