package kind.x1.interpreter.types;

import kind.x1.Optional;
import kind.x1.interpreter.*;
import kind.x1.DiagnosticProducer;
import java.util.List;
import java.util.ArrayList;

public class FunctionType implements Type
{
    private List<Type> parameters;
    private Optional<Type> returnType;
    
    public FunctionType (List<Type> p, Optional<Type> r) { parameters = p; returnType = r; }
    
    public String getName()
    {
        StringBuilder b = new StringBuilder("(");
        String sep = "";
        for (Type t : parameters)
        {
            b.append(sep).append(t.getName());
            sep = ", ";
        }
        b.append (") -> ");
        if (returnType.isPresent()) 
            b.append(returnType.get().getName());
        else
            b.append("noreturn");    
        return b.toString();
    }
    public boolean isFullyResolved()
    {
        for (Type t : parameters) if (!t.isFullyResolved()) return false;
        if (returnType.isPresent() && ! returnType.get().isFullyResolved()) return false;
        return true;
    }
    public Optional<Type> resolve (Resolver r, DiagnosticProducer diag)
    {
        if (isFullyResolved())
            return Optional.of(this);
        List<Type> p = new ArrayList<>(parameters.size());
        for (Type t : parameters)
            if (t.isFullyResolved())
                p.add(t);
            else
            {
                Optional<Type> rt = t.resolve(r, diag);
                if (!rt.isPresent()) return Optional.empty();
                p.add(rt.get());
            }
        Optional<Type> rrt = returnType;
        if (returnType.isPresent() && ! returnType.get().isFullyResolved()) 
        {
            rrt = returnType.get().resolve(r, diag);
            if (!rrt.isPresent()) return rrt;
        }
        return Optional.of(new FunctionType(p,rrt));           
    }
    
    public List<Type> getParameters() { return parameters; }
    public Optional<Type> getReturnType () { return returnType; }
}
