package kind.x1.interpreter.test;

import kind.x1.*;
import kind.x1.ast.*;
import kind.x1.misc.*;
import kind.x1.interpreter.*;
import kind.x1.interpreter.symbols.Symbol;
import kind.x1.interpreter.symbols.SymbolBuilder;

import java.util.List;
import java.util.Collections;

public class ModuleBuilderTest extends Assertions implements Runnable
{
    public void run()
    {
        importSpecified();
        cannotImportUnexportedSymbol();
        importWildcard();
        definition();
        exportedDefinition();
        export();
    }
    public void importSpecified()
    {
        ModuleBuilder b = new ModuleBuilder();
        Module testModule = new Module();
        Symbol testSymbol = new TestSymbol ("testSymbol");
        testModule.getLocalScope().addSymbol (testSymbol);
        testModule.export ("testSymbol");
        b.setModuleResolver (new StaticModuleResolver ().add(SID.from("test::module"), testModule));
        b.importSpecified (SID.from("test::module"), Collections.singletonList("testSymbol"), Optional.empty());
        Module built = b.build();
        
        assertEqual ("importSpecified: testSymbol should be defined in local scope", 
            built.getLocalScope().getSymbol ("testSymbol").orElse(null),
            testSymbol);
    }
    public void cannotImportUnexportedSymbol()
    {
        ModuleBuilder b = new ModuleBuilder();
        TestDiagnosticProducer tdp = new TestDiagnosticProducer();
        b.setDiagnosticProducer (tdp);
        Module testModule = new Module();
        Symbol testSymbol = new TestSymbol ("testSymbol");
        testModule.getLocalScope().addSymbol (testSymbol);
        // not done: testModule.export ("testSymbol");
        b.setModuleResolver (new StaticModuleResolver ().add(SID.from("test::module"), testModule));
        b.importSpecified (SID.from("test::module"), Collections.singletonList("testSymbol"), Optional.empty());
        Module built = b.build();
        
        assertEqual ("cannotImportUnexportedSymbol: testSymbol should not be defined in local scope", 
            built.getLocalScope().getSymbol ("testSymbol"),
            Optional.empty());
        assertEqual ("cannotImportUnexportedSymbol: should have produced an error message",
            tdp.getErrors().size(),
            1);
    }
    public void importWildcard()
    {
        ModuleBuilder b = new ModuleBuilder();
        Module testModule = new Module();
        Symbol testSymbol1 = new TestSymbol ("testSymbol1");
        Symbol testSymbol2 = new TestSymbol ("testSymbol2");
        Symbol testSymbol3 = new TestSymbol ("testSymbol3");
        testModule.getLocalScope().addSymbol (testSymbol1);
        testModule.getLocalScope().addSymbol (testSymbol2);
        testModule.getLocalScope().addSymbol (testSymbol3);
        testModule.export ("testSymbol1");
        testModule.export ("testSymbol2");
        b.setModuleResolver (new StaticModuleResolver ().add(SID.from("test::module"), testModule));
        b.importWild (SID.from("test::module"), Optional.empty());
        Module built = b.build();
        
        assertEqual ("importWildcard: testSymbol1 should be defined in local scope", 
            built.getLocalScope().getSymbol ("testSymbol1").orElse(null),
            testSymbol1);
        assertEqual ("importWildcard: testSymbol2 should be defined in local scope", 
            built.getLocalScope().getSymbol ("testSymbol2").orElse(null),
            testSymbol2);
        assertEqual ("importWildcard: testSymbol3 should not be defined in local scope", 
            built.getLocalScope().getSymbol ("testSymbol3"),
            Optional.empty());
    }
    public void definition()
    {
        ModuleBuilder b = new ModuleBuilder();
        TestSymbol sym = new TestSymbol("testSymbol");
        final TestSymbolBuilder tsb = new TestSymbolBuilder(sym);
        final boolean [] called = new boolean[1];
        
        b.setSymbolBuilderFactory ( new StaticFactory<SymbolBuilder>(tsb));
        b.define (new DefnVisitor.Visitable() {
            public void visit (DefnVisitor v) {
                assertEqual ("definition: visitor should be symbol builder", v, tsb);
                called[0] = true;
            }
        });
        assertTrue ("definition: definition.visit not called", called[0]);
        
        assertEqual ("definition: testSymbol should be defined", 
            b.build().getLocalScope().getSymbol("testSymbol"),
            Optional.of(sym));
    }
    public void exportedDefinition()
    {
        ModuleBuilder b = new ModuleBuilder();
        TestSymbol sym = new TestSymbol("testSymbol");
        final TestSymbolBuilder tsb = new TestSymbolBuilder(sym);
        final boolean [] called = new boolean[1];
        
        b.setSymbolBuilderFactory ( new StaticFactory<SymbolBuilder>(tsb));
        b.defineAndExport (new DefnVisitor.Visitable() {
            public void visit (DefnVisitor v) {
                assertEqual ("exportedDefinition: visitor should be symbol builder", v, tsb);
                called[0] = true;
            }
        });
        assertTrue ("exportedDefinition: definition.visit not called", called[0]);
        
        Module built = b.build();
        
        assertEqual ("exportedDefinition: testSymbol should be defined", 
            built.getLocalScope().getSymbol("testSymbol"),
            Optional.of(sym));
        assertEqual ("exportedDefinition: testSymbol should be exported", 
            built.getExportedSymbol("testSymbol"),
            Optional.of(sym));
    }
    public void export()
    {
        ModuleBuilder b = new ModuleBuilder();
        // inject a symbol to export by importing from another module:
        Module testModule = new Module();
        Symbol testSymbol = new TestSymbol ("testSymbol");
        testModule.getLocalScope().addSymbol (testSymbol);
        testModule.export ("testSymbol");
        b.setModuleResolver (new StaticModuleResolver ().add(SID.from("test::module"), testModule));
        b.importSpecified (SID.from("test::module"), Collections.singletonList("testSymbol"), Optional.empty());
        // and export it:
        b.export("testSymbol");
        
        Module built = b.build();
        
        assertEqual ("export: testSymbol should be exported", 
            built.getExportedSymbol ("testSymbol"),
            Optional.of(testSymbol));
    }
}
