package kind.x1.ast;

import kind.x1.misc.SID;

public class ExprVisitor 
{
    public interface Visitable { void visit (ExprVisitor visitor); }
    public interface LiteralFlagVisitor 
    { 
        void literalFlag (String value);
    }
    
    public LiteralFlagVisitor intLiteral (String text) 
    { 
        return IGNORE_LITERAL_FLAGS;
    }
    
    public void variableRef (SID id) { }
    
    public void beginOperatorChainRight () { }
    public void beginOperatorChainLeft () { }
    public ExprVisitor operand () { return IGNORE_SUBEXPRESSION; }
    public void operator (String operator) { }
    public void endOperatorChain () { }
    
    public void applyDot (String id) { }
    
    public static final LiteralFlagVisitor IGNORE_LITERAL_FLAGS = new LiteralFlagVisitor() {
            public void literalFlag (String value) { }
        };
    public static final ExprVisitor IGNORE_SUBEXPRESSION = new ExprVisitor();
}
