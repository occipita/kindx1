package kind.x1.interpreter.executables;

public interface Evaluatable 
{
    
}
