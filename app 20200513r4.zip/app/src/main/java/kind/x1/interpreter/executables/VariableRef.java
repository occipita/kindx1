package kind.x1.interpreter.executables;

import kind.x1.misc.SID;

public class VariableRef implements Evaluatable
{
    private SID id;
    
    public VariableRef (SID id) { this.id = id; }
    public SID getId () { return id; }    
}
