package kind.x1.interpreter.executables;

import java.util.List;
import java.util.ArrayList;

public class OperatorChain implements Evaluatable 
{
    public static class Operator
    {
        private String name;
        
        public Operator(String n) { name = n; }
        public String getName() { return name; }
    }
    private List<Evaluatable> operands = new ArrayList<>();
    private List<Operator> operators = new ArrayList<>();
    private boolean rightAssoc;
    
    public OperatorChain (boolean rightAssoc)
    {
        this.rightAssoc = rightAssoc;
    }
    
    public List<Evaluatable> getOperands() { return operands; }
    public List<Operator> getOperators() { return operators; }
    public boolean isRightAssoc () { return rightAssoc; }      
}
