package kind.x1.interpreter;

import kind.x1.Optional;
import kind.x1.interpreter.*;
import kind.x1.DiagnosticProducer;
import kind.x1.interpreter.types.*;
import java.util.*;

public class TypeParameterContext 
{
    public class Parameter implements Type
    {
        private String name;
        //private boolean isImplicit'
        
        public Parameter(String name) { this.name = name; }
        public String getName () { return name; } 
        public boolean isFullyResolved () { return true; }
        public Optional<Type> resolve (Resolver r, DiagnosticProducer diag)
        {
            return Optional.of(this);
        }
    } 
    public class Constructor implements Type
    {
        private Type type;
        //private boolean isImplicit'
        
        public Constructor(Type type) { this.type = type; }
        public String getName () 
        { 
            StringBuilder sb = new StringBuilder("forall ");
            String sep = "";
            for (Parameter p:parameters)
            {
                sb.append(sep).append(p.getName());
                sep = ", ";
            }
            sep = " : ";
            for (Constraint c : constraints)
            {
                sb.append(sep).append(c.getDescription());
                sep = ", ";
            }
            sb.append(" . ").append(type.getName());
            return sb.toString(); 
        } 
        public boolean isFullyResolved () { return type.isFullyResolved(); }
        public Optional<Type> resolve (Resolver r, DiagnosticProducer diag)
        {
            return Optional.of(this);
        }
        
    } 
    
    private List<Parameter> parameters = new ArrayList<>();
    private List<Constraint> constraints = new ArrayList<>();
    
    private int counter = 0;
    
    public Parameter addImplicit ()
    {
        Parameter p = new Parameter("_"+(++counter));
        parameters.add(p);
        return p;
    }
    public Parameter addExplicit (String name)
    {
        Parameter p = new Parameter(name);
        parameters.add(p);
        return p;
    }
    public void addConstraint(Constraint c) { constraints.add(c); }
    public Constructor getConstructor (Type type)
    {
        return new Constructor(type);
    }
}
