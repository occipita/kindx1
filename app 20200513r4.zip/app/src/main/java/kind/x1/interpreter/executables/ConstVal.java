package kind.x1.interpreter.executables;

import kind.x1.interpreter.types.Type;
import kind.x1.interpreter.values.KVal;

public class ConstVal implements Evaluatable
{
    private final KVal value;
    private final Type type;
    
    public ConstVal (KVal v, Type t) { value = v; type = t; }
    public KVal getValue() { return value; }
    public Type getType () { return type; }
}
