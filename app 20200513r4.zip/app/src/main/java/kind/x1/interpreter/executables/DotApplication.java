package kind.x1.interpreter.executables;

public class DotApplication implements Evaluatable
{
    private Evaluatable subExpr;
    private String id;
    
    public DotApplication(Evaluatable sub, String id) { subExpr = sub; this.id = id; }
    public Evaluatable getSubExpr () { return subExpr; }
    public String getId () { return id; }
}
