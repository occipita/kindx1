package kind.x1;

public interface Factory<T> 
{
    T create();   
}
