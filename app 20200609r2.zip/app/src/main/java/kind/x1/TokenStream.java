package kind.x1;

public interface TokenStream 
{
    public Token nextToken();
}
