package kind.x1.interpreter.executables;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import kind.x1.interpreter.types.*;
import kind.x1.interpreter.values.KVal;
import kind.x1.interpreter.*;
import kind.x1.*;


public class OperatorChain implements Evaluatable 
{
    private enum TypeRule
    {
        NONE { 
            boolean apply (OperatorChain oc, int index, Operator op, TypeSpec target) { return false; } 
        },
        ARITHMETIC {
            boolean apply (OperatorChain oc, int index, Operator op, TypeSpec target)
            {
                // FIXME wwe have nowhere near enough tests for this
                // FIXME is more  specific the best test?
                Optional<Type> t = oc.getLHSType(index); 
                t = selectMostSpecificType(t, oc.getRHSType(index)); 
                t = selectMostSpecificType(t, target.getInferredType()); 
                t = selectMostSpecificType(t, op.lhsTarget.getInferredType()); 
                t = selectMostSpecificType(t, op.rhsTarget.getInferredType()); 
                if (op.debug) System.out.println ("ARITHMETIC.apply(index): target: "+target+" chosen: "+t);
                if (t.isPresent())
                {
                    TypeSpec updatedTarget = TypeSpec.subtypeOf(t.get());
                    boolean updated = false;
                    if (updatedTarget.isMoreSpecificThan(op.lhsTarget)) {
                        updated = true;
                        op.lhsTarget = updatedTarget;
                    }
                    if (updatedTarget.isMoreSpecificThan(op.rhsTarget)) {
                        updated = true;
                        op.rhsTarget = updatedTarget;
                    }       
                    op.resultType = t;
                    return updated;
                }
                return false;
            }
        },
        COMPARISON {
            boolean apply (OperatorChain oc, int index, Operator op, TypeSpec target)
            {
                return false; 
            }
        },
        ASSIGNMENT {
            boolean apply (OperatorChain oc, int index, Operator op, TypeSpec target)
            {
                // FIXME wwe have nowhere near enough tests for this
                // FIXME is more  specific the best test?
                Optional<Type> t = Ref.strip(oc.getLHSType(index));
                t = selectMostSpecificType(t, oc.getRHSType(index)); 
                t = selectMostSpecificType(t, target.getInferredType()); 
                t = selectMostSpecificType(t, Ref.strip(op.lhsTarget.getInferredType())); 
                t = selectMostSpecificType(t, op.rhsTarget.getInferredType()); 
                if (op.debug) System.out.println ("ASSIGNMENT.apply(index): target: "+target+" chosen: "+t);
                if (t.isPresent())
                {
                    TypeSpec updatedTarget = TypeSpec.subtypeOf(t.get());
                    TypeSpec refTarget = TypeSpec.exactly(new Ref(t.get()));
                    boolean updated = false;
                    if (refTarget.isMoreSpecificThan(op.lhsTarget)) {
                        updated = true;
                        op.lhsTarget = refTarget;
                    }
                    if (updatedTarget.isMoreSpecificThan(op.rhsTarget)) {
                        updated = true;
                        op.rhsTarget = updatedTarget;
                    }       
                    op.resultType = t;
                    return updated;
                }
                return false;
            }
        };
        
        abstract boolean apply (OperatorChain oc, int index, Operator op, TypeSpec target); 
    }
    private static HashMap<String, TypeRule> operatorTypeRules = new HashMap<>();
    static
    {
        operatorTypeRules.put ("+", TypeRule.ARITHMETIC);
        operatorTypeRules.put ("-", TypeRule.ARITHMETIC);
        operatorTypeRules.put ("*", TypeRule.ARITHMETIC);
        operatorTypeRules.put ("/", TypeRule.ARITHMETIC);
        
        operatorTypeRules.put ("=", TypeRule.ASSIGNMENT);
        // FIXME more rules
    }
    public static class Operator
    {
        private String name;
        private TypeRule typeRule;
        private Optional<Type> resultType = Optional.empty();
        private TypeSpec lhsTarget = TypeSpec.UNSPECIFIED;
        private TypeSpec rhsTarget = TypeSpec.UNSPECIFIED;
        private boolean debug;
        
        public Operator(String n) 
        { 
            name = n; 
            typeRule = operatorTypeRules.get(n);
            if (typeRule == null) typeRule = TypeRule.NONE;
        }
        public String getName() { return name; }
        public Operator debug() { debug = true; return this; }
        private boolean inferType (OperatorChain chain, int index, TypeSpec target)
        {
            return typeRule.apply (chain, index, this, target);
        }
    }
    private List<Evaluatable> operands = new ArrayList<>();
    private List<Operator> operators = new ArrayList<>();
    private boolean rightAssoc;
    
    public OperatorChain (boolean rightAssoc)
    {
        this.rightAssoc = rightAssoc;
    }
    
    public List<Evaluatable> getOperands() { return operands; }
    public List<Operator> getOperators() { return operators; }
    public boolean isRightAssoc () { return rightAssoc; }      
    
    public boolean inferTypesSilently (Resolver resolver, TypeSpec target) 
    {
        boolean updated;
        do
        {
            updated = false;
            // LTR pass
            for (int i = 0; i < operators.size (); i ++)
            {
                Operator op = operators.get(i);
                TypeSpec optarget = getTargetType(i, target);
                updated = op.inferType(this, i, optarget) || updated;
                // FIXME this should be different for right assoc
                if (i == 0)
                    operands.get(0).inferTypesSilently (resolver, op.lhsTarget);
                operands.get(i+1).inferTypesSilently (resolver, op.rhsTarget);
                if (op.debug) dumpOp(i);
            }
            if (!updated) break;
            // RTL pass
            updated = false;
            for (int i = operators.size() - 1; i >= 0; i --)
            {
                Operator op = operators.get(i);
                TypeSpec optarget = getTargetType(i, target);
                updated = op.inferType(this, i, optarget) || updated;
                if (i == 0)
                    operands.get(0).inferTypesSilently (resolver, op.lhsTarget);
                operands.get(i+1).inferTypesSilently (resolver, op.rhsTarget);
                if (op.debug) dumpOp(i);
            }
        } 
        while(updated);
        return true; 
    }
    public boolean inferTypes (Resolver resolver, TypeParameterContext context, DiagnosticProducer diag, TypeSpec expected) 
    {
        boolean typesUpdated;
        do
        {
            typesUpdated = false;
            // LTR pass
            for (int i = 0; i < operators.size (); i ++)
            {
                Operator op = operators.get(i);
                TypeSpec optarget = getTargetType(i, expected);
                typesUpdated = op.inferType(this, i, optarget) || typesUpdated;
                // FIXME this should be different for right assoc
                if (i == 0)
                    operands.get(0).inferTypes (resolver, context, diag, op.lhsTarget);
                typesUpdated = ensureMatch (op.lhsTarget, getLHSType(i), context, diag) || typesUpdated;
                operands.get(i+1).inferTypes (resolver, context, diag, op.rhsTarget);
                typesUpdated = ensureMatch (op.rhsTarget, getRHSType(i), context, diag) || typesUpdated;
                if (op.debug) dumpOp(i);
            }
        } while(typesUpdated);
        return true; 
    }
    private void dumpOp (int i)
    {
        Operator op=operators.get(i);
        System.out.println ("op "+i+" ("+op.getName() + ") lhs target: " + op.lhsTarget + " lhs: " + getLHSType(i) + 
                 " rhs target: " + op.rhsTarget + " rhs: " + getRHSType(i) + 
                 " result target: " + getTargetType (i, TypeSpec.UNSPECIFIED) + " result: " + op.resultType);
    }
    private boolean ensureMatch (TypeSpec spec, Optional<Type> type, TypeParameterContext context, DiagnosticProducer diag)
    {
        if (!type.isPresent()) return false;
        Type t = type.get ();
        if (!spec.matches (t))
        {
            if (t instanceof TypeParameterContext.Parameter && 
                ((TypeParameterContext.Parameter)t).isImplicit() &&
                ((TypeParameterContext.Parameter)t).isFullyResolved()) // fully resolved => not already unified
            {
                ((TypeParameterContext.Parameter)t).unifyWith(spec.getInferredType());
                return true;
            }
            // FIXME scan scopes for objects that can injectc ode to resolve this discreapncy
        }
        return false;
    } 
    public boolean checkTypes (DiagnosticProducer diag) 
    {
        // FIXME check operands
        // FIXME check operators are defined with correct types 
        return true; 
    }

    private int lastOpIndex () { return rightAssoc ? 0 : operators.size() - 1; }
    public Optional<Type> getResultType () 
    { 
        return operators.get(lastOpIndex()).resultType; 
    }

    private Optional<Type> getLHSType (int index)
    {
        // FIXME what about right associative chains?
        if (index == 0) return operands.get(0).getResultType();
        return operators.get(index - 1).resultType;
    }
    private Optional<Type> getRHSType (int index)
    {
        // FIXME what about right associative chains?
        return operands.get(index + 1).getResultType();
    }
    private TypeSpec getTargetType (int index, TypeSpec chainTarget)
    {
        // FIXME what about right associative chains?
        if (index == lastOpIndex()) return chainTarget;
        return operators.get(index + 1).lhsTarget;
    }
    private static Optional<Type> selectMostSpecificType(Optional<Type> t1, Optional<Type> t2)
    {
        if (!t1.isPresent()) return t2;
        if (!t2.isPresent()) return t1;
        Type tt1 = t1.get(), tt2 = t2.get();
        // prefer typesthat are concrete rather than parameters
        if (tt2 instanceof TypeParameterContext.Parameter) return t1;
        if (tt1 instanceof TypeParameterContext.Parameter) return t2;
        // fixme subtypes
        return t1;
    }
}
