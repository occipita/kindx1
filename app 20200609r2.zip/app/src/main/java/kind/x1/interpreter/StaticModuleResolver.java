package kind.x1.interpreter;

import java.util.Map;
import java.util.HashMap;
import kind.x1.misc.SID;
import kind.x1.Optional;

public class StaticModuleResolver implements ModuleResolver
{
    private final Map<SID, Module> modules = new HashMap<>();
    
    public Optional<Module> findModule (SID name) { return Optional.ofNullable(modules.get(name)); }
    public StaticModuleResolver add (SID sid, Module mod) { modules.put(sid,mod); return this; }
}
