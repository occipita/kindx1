package kind.x1.misc;

public interface Predicate<T> 
{
    boolean test(T value);
}
