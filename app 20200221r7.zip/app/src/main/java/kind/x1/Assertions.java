package kind.x1;

public class Assertions 
{
    protected void assertEqual (String msg, Object a, Object b)
    {
        if ((a == null && b != null) || (a != null && b == null) || (a != null && !a.equals(b)))
        {
            fail(msg + " " + a + " != " + b);
        }
    }

    protected void assertTrue (String msg, boolean flag)
    {
        if (!flag)
            fail(msg);
    }           

    protected void assertFalse (String msg, boolean flag) { assertTrue (msg, !flag); }
    protected void fail(String msg) { System.err.println(getClass().getName()+"."+msg); }
}
