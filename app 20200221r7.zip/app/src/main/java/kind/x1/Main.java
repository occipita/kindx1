package kind.x1;

public class Main
{
    public static void main(String [] args)
    {
        new NDFATest().run();
        new LexerTest().run();
        new TokenStreamMutatorTest().run();
        new GSSTest().run();
        new ATNTest().run();
        new ALLStarTest().run();
    }
}