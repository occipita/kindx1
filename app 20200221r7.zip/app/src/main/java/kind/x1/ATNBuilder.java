package kind.x1;

public class ATNBuilder 
{
    ATN building = new ATN();
    int productionCount = 0;
    
    public class Production
    {
        String stateNamePrefix;
        int stateCount = 0;
        int number;
        ATN.State current;
        ATN.State next;
        ATN.State accept;
        ATN.State optionalStart; // nb would need a stack to handle nested optionals...
        ATN.SymbolLink lastLink;
        
        ATN.State newState ()
        {
            if (next != null) return next;
            return next = building.newState(stateNamePrefix+"."+(++stateCount), number);
        }
        void move ()
        {
            current = next;
            next = null;
        }
        public Production token (int tokenType)
        {
            lastLink = current.addTokenLink(tokenType, newState());
            move();
            return this;
        }
        public Production handler (String name)
        {
            building.handlers.put (number, name);
            return this;
        }
        public ATNBuilder done ()
        {
            current.addEpsilonLink(accept);
            return ATNBuilder.this;
        }
        public Production beginOptional()
        {
            if (optionalStart != null) throw new IllegalArgumentException("Cannot nest optionals @" + current.getName());
            optionalStart = current;
            return this;
        }
        public Production endOptional()
        {
            optionalStart.addEpsilonLink(current);
            optionalStart = null;
            return this;
        }
        public Production nonterminal (String name)
        {
            lastLink = current.addNonterminalLink (name, newState());
            building.addReturnSite (name, next);
            move();
            return this;
        }
        public Production asArg (int index)
        {
            lastLink.captureArg = index;
            return this;
        } 
    }

    public Production addProduction(String name)
    {
        Production r = new Production();
        r.number = (++productionCount);
        ATN.State start = building.findState(name);
        if (start == null)
        {
            start = building.newState(name, -1);   
            r.accept = building.newState(name+":accept", -1);
            r.accept.acceptState = true;
        }
        else
            r.accept = building.findState(name+":accept");
        r.stateNamePrefix = name+"$"+r.number;
        start.addEpsilonLink (r.newState());
        r.move();
        return r;
    }
        
    public ATNBuilder withListener (Object listener)
    {
        building.listener = listener;
        return this;
    }    
    
    public ATN build ()
    {
        return building;
    }
}
