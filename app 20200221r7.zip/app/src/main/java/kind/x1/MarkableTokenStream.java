package kind.x1;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

public class MarkableTokenStream implements TokenStream
{
    TokenStream source;
    List<Token> buffering = null;
    Iterator<Token> replaying = null;
    
    public MarkableTokenStream (TokenStream src) { source = src; }
    public Token nextToken()
    {
        Token t;
        if (replaying != null && replaying.hasNext())
            t = replaying.next();
        else 
            t = source.nextToken();
            
        if (buffering != null) buffering.add(t);
        
        return t;
    }
    
    public void mark()
    {
        buffering = new ArrayList<>();
    }
    
    public void rewind ()
    {
        replaying = buffering.iterator();
        buffering = null;
    }
    
    public void release ()
    {
        buffering = null;
    }
}
