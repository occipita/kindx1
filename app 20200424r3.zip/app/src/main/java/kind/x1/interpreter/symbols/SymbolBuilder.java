package kind.x1.interpreter.symbols;

import kind.x1.ast.*;
import kind.x1.*;
import kind.x1.misc.SID;
import kind.x1.interpreter.executables.*;
import kind.x1.interpreter.types.TypeBuilder;

import java.util.List;

public class SymbolBuilder extends DefnVisitor
{
    private Symbol building;
    private Factory<ExecutableBuilder> executableBuilderFactory = ExecutableBuilder.FACTORY;
    private Factory<TypeBuilder> typeBuilderFactory = TypeBuilder.FACTORY;
    
    
    public Symbol build() { return building; }
    public void setExecutableBuilderFactory (Factory<ExecutableBuilder> f) { executableBuilderFactory = f; }
    public void setTypeBuilderFactory (Factory<TypeBuilder> f) { typeBuilderFactory = f; }
    
    public DefnVisitor property (String name, Optional<Type> type) //FIXME should be TypeVisitor.Visitable (or perhaps method to ret a visitor)
    {
        TypeBuilder tb = typeBuilderFactory.create();
        type.get().visit(tb);
        building = new PropertySymbol(name, tb.build()); 
        return this; 
    }
    public void propertyAccessor (Defn.AccessorType type, StmtVisitor.Visitable statement) 
    {
        ExecutableBuilder eb = executableBuilderFactory.create();
        statement.visit (eb);
        Executable e = eb.build();
        ((PropertySymbol)building).addAccessor (type, e); 
    }
    

    public static final Factory<SymbolBuilder> FACTORY = new Factory<SymbolBuilder>() {
        public SymbolBuilder create() { return new SymbolBuilder(); } 
    };
}
