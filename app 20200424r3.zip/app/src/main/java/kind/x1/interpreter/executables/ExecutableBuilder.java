package kind.x1.interpreter.executables;

import kind.x1.ast.*;
import kind.x1.Factory;

public class ExecutableBuilder extends StmtVisitor
{
    private Executable building = Executable.NULL_EXECUTABLE; // default if no visitor methods called
    public Executable build() { return building; }
    
    public static final Factory<ExecutableBuilder> FACTORY = new Factory<ExecutableBuilder>() {
        public ExecutableBuilder create() { return new ExecutableBuilder(); }
    };
}
