package kind.x1.interpreter.types;

public interface Type 
{
    String getName();
    boolean isFullyResolved();
}
