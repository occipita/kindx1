package kind.x1.interpreter.test;

import kind.x1.*;
import kind.x1.misc.*;
import kind.x1.interpreter.*;
import kind.x1.interpreter.types.*;

import java.util.List;
import java.util.Collections;

public class TypeBuilderTest extends Assertions implements Runnable
{
    public void run()
    {
        namedType();
    }

    public void namedType ()
    {
        TypeBuilder b =new TypeBuilder();
        b.namedType (SID.from("type::name"));
        Type t = b.build();
        assertEqual ("namedType: result class", t.getClass(), TypeReference.class);
        assertFalse ("namedType: result should not be fully resolved", t.isFullyResolved());
    }
    
}
