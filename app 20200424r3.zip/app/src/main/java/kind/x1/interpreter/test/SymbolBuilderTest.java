package kind.x1.interpreter.test;

import kind.x1.*;
import kind.x1.ast.*;
import kind.x1.misc.*;
import kind.x1.interpreter.*;
import kind.x1.interpreter.symbols.*;
import kind.x1.interpreter.types.TypeReference;

import java.util.List;
import java.util.Collections;

public class SymbolBuilderTest extends Assertions implements Runnable
{
    public void run()
    {
        simpleProperty();
        propertyWithAccessors();
    }
    
    public void simpleProperty()
    {
        SymbolBuilder b = new SymbolBuilder ();
        b.property ("test", Optional.of(new Type.NamedType(SID.from("int"))));
        b.endProperty();
        PropertySymbol s = (PropertySymbol)b.build();
        assertEqual("simpleProperty: name", s.getName(), "test");
        assertEqual("simpleProperty: class of type", s.getType().getClass(), TypeReference.class);
    }
    
    public void propertyWithAccessors()
    {
        SymbolBuilder b = new SymbolBuilder ();
        DefnVisitor v = b.property ("test", Optional.of(new Type.NamedType(SID.from("int"))));
        v.propertyAccessor(Defn.AccessorType.GET, new Stmt.Ret(new Expr.IntLiteral("42",Collections.emptyList())));
        b.endProperty();
        PropertySymbol s = (PropertySymbol)b.build();
        assertTrue ("propertyWithAccessors: has a getter", s.getAccessor(Defn.AccessorType.GET).isPresent());
    }
    
}
