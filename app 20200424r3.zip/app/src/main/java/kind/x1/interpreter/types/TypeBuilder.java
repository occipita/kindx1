package kind.x1.interpreter.types;

import kind.x1.ast.TypeVisitor;
import kind.x1.ast.ExprVisitor;
import kind.x1.misc.SID;
import kind.x1.Factory;


public class TypeBuilder extends TypeVisitor
{
    Type building;
    
    public Type build()
    {
        // FIXME resolve before returning where possible
        return building;
    }
    
    public void namedType (SID name) 
    {
        building = new TypeReference (name); 
    }
    public void expression (ExprVisitor.Visitable expr) { }
    public void beginConstructorCall () { }
    public TypeVisitor visitConstructor () { return null; }
    public TypeVisitor visitConstructorArg () { return null; }
    public void endConstructorCall () { }

    public static final Factory<TypeBuilder> FACTORY = new Factory<TypeBuilder>() {
        public TypeBuilder create() { return new TypeBuilder(); }
    };
    
}
