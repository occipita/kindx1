package kind.x1.ast;

import kind.x1.misc.SID;

public class TypeVisitor 
{
    public interface Visitable { void visit(TypeVisitor visitor); }
    
    public void namedType (SID name) { }
    public void expression (ExprVisitor.Visitable expr) { }
    public void beginConstructorCall () { }
    public TypeVisitor visitConstructor () { return null; }
    public TypeVisitor visitConstructorArg () { return null; }
    public void endConstructorCall () { }
}
