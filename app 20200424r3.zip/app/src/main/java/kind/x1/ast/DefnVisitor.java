package kind.x1.ast;

import kind.x1.Optional;

public class DefnVisitor 
{
    public interface Visitable { void visit (DefnVisitor visitor); }
    
    /** Called to define a property
     *  @return a visitor to receive accessor definitions, or null to skip accessors
     */
    public DefnVisitor property (String name, Optional<Type> type) { return null; }
    public void propertyAccessor (Defn.AccessorType type, StmtVisitor.Visitable statement) { }
    public void endProperty () { }
    
}
