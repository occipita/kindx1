package kind.x1.ast;

public class ExprVisitor 
{
    public interface Visitable { void visit (ExprVisitor visitor); }
}
