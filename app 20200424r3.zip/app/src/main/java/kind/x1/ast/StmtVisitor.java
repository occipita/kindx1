package kind.x1.ast;

public class StmtVisitor 
{
    public interface Visitable { void visit (StmtVisitor visitor); }
}
