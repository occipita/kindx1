package kind.x1.interpreter;

import kind.x1.ast.*;

public class ModuleBuilder extends ModVisitor
{
    ModuleResolver moduleResolver = ModuleResolver.NULL;
    
    public Module build()
    {
        return new Module();
    }
    
    public void setModuleResolver (ModuleResolver r) { moduleResolver = r; }
}
