package kind.x1.interpreter;

public class Module 
{
    private final Scope localScope = new Scope();
    
    public Scope getLocalScope() { return localScope; }
    public void export (String name) { } 
}
