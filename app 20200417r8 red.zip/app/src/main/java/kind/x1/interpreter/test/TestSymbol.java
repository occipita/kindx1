package kind.x1.interpreter.test;

import kind.x1.interpreter.*;

public class TestSymbol implements Symbol 
{
    private final String name;
    
    public TestSymbol (String n) { name = n; }
    public String getName() { return name; }
}
