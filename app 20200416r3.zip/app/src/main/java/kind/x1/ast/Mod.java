package kind.x1.ast;

import kind.x1.*;
import kind.x1.misc.*;
import java.util.List;
import java.util.Collections;

public class Mod 
{
    public static class Import
    {
        private final SID base;
        private final boolean wild;
        private final Optional<List<String>> ids;
        private final Optional<SID> as;
        
        public Import (SID b, boolean w, Optional<List<String>> i, Optional<SID> a)
        {
            base = b;
            wild = w;
            ids = i.map(Mappers.mapToUnmodifiableList());
            as = a;
        }
        public String toString()
        {
            return "Mod.Import<"+base+","+wild+","+ids.map(Mappers.MAP_TO_STRING).orElse("-")+","+as.map(Mappers.MAP_TO_STRING).orElse("default")+">";
        }
    }
    
    public static class Export
    {
        private final List<String> ids;
        
        public Export(List<String> i) { ids = Collections.unmodifiableList(i); }
        public String toString() { return "Mod.Export<"+ids+">"; }
    }
    
    static class Handler
    {
        public Import importSpecified (List<String> ids, SID base, Optional<SID> as) { return new Import(base,false,Optional.of(ids),as); } 
        public Import importWild (SID base, Optional<SID> as) { return new Import(base,true,Optional.empty(),as); } 
        public Export export (List<String> ids) { return new Export(ids); }
    }
    
    
}
