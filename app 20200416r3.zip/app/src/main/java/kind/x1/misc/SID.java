package kind.x1.misc;

import java.util.*;

public class SID 
{
    private final List<String> ids;
    
    public SID(List<String> i) { ids = Collections.unmodifiableList(i); }
    public List<String> getIds() { return ids; }
    public String toString() { 
        StringBuilder sb = new StringBuilder();
        String s = "";
        for (String id : ids) {
            sb.append(s).append(id);
            s = "::";
        }
        return sb.toString();
    }
}
