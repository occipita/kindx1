package kind.x1.grammar;

import kind.x1.*;
import static kind.x1.TokenType.*;

public class Misc 
{
    public static ATNBuilder apply (ATNBuilder builder)
    {
        return builder               
                           
            .addLowPriorityProduction("id").s(UNDERSCORE,"id").handler("mergeId").done()
            .addLowPriorityProduction("id").s(ID).handler("copy").done()
            
            .addProduction("sid").beginRepeating().sl("id").repeatWithSeparator(DBLCOLON).handler("sid").done()
            
            .addProduction("id-list").beginRepeating().sl("id").repeatWithSeparator(COMMA).handler("tokenListToStrings").done()
            .addProduction("sid-list").beginRepeating().sl("sid").repeatWithSeparator(COMMA).handler("copy").done()
            ;
    }

}
