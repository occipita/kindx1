package kind.x1.interpreter.test;

import kind.x1.interpreter.executables.Executable;

public class TestExecutable implements Executable
{

}
