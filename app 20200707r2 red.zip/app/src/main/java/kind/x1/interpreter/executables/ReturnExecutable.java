package kind.x1.interpreter.executables;

public class ReturnExecutable implements Executable
{

}
