package kind.x1.interpreter.test;

import kind.x1.interpreter.symbols.Symbol;

public class TestSymbol extends Symbol 
{    
    public TestSymbol (String n) { super (n); }
}
