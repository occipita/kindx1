package kind.x1.interpreter.executables;

import kind.x1.misc.SID;
import kind.x1.interpreter.types.*;
import kind.x1.interpreter.values.KVal;
import kind.x1.interpreter.*;
import kind.x1.*;

public class VariableRef implements Evaluatable
{
    private SID id;
    private Optional<Type> type = Optional.empty();
    
    public VariableRef (SID id) { this.id = id; }
    public SID getId () { return id; }    
    
    public boolean inferTypesSilently (Resolver resolver, TypeSpec target) { return false; }
    public boolean inferTypes (Resolver resolver, TypeParameterContext context, DiagnosticProducer diag, TypeSpec expected) { return true; }
    public boolean checkTypes (DiagnosticProducer diag) { return false; }

    public Optional<Type> getResultType () { return type; }
}
