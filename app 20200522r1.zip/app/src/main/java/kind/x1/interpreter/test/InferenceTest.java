package kind.x1.interpreter.test;

import kind.x1.*;
import kind.x1.misc.*;
import kind.x1.interpreter.*;
import kind.x1.interpreter.types.*;
import kind.x1.interpreter.executables.*;
import kind.x1.interpreter.types.primitive.*;

import java.util.List;
import java.util.Collections;

public class InferenceTest extends Assertions implements Runnable
{
    public void run ()
    {
        constValKnowsType();
        noInferenceOnDeclared();
        dotOnImplicitParamAddsConstraint();
    }
    
    public void constValKnowsType()
    {
        ConstVal cv = new ConstVal(null, LiteralTypes.INTLITERAL);
        TestDiagnosticProducer diag = new TestDiagnosticProducer();
        TypeParameterContext tpc = new TypeParameterContext();
        assertTrue ("constValKnowsType: inferTypesSilently succeeds", cv.inferTypesSilently (Resolver.EMPTY, TypeSpec.UNSPECIFIED));
        assertTrue ("constValKnowsType: inferTypes succeeds", cv.inferTypes (Resolver.EMPTY, tpc, diag, TypeSpec.UNSPECIFIED));
        assertTrue ("constValKnowsType: checkTypes succeeds", cv.checkTypes (diag));
        assertEqual ("constValKnowsType: should not produce any errors", diag.getErrors().toString(), "[]"); 
        assertEqual ("constValKnowsType: final type", cv.getResultType(), Optional.of(LiteralTypes.INTLITERAL));
    }
    public void noInferenceOnDeclared ()
    {
        TypeParameterContext tpc = new TypeParameterContext();
        Type t1 = tpc.addExplicit ("T1");
        DotApplication dotapp = new DotApplication(new ConstVal(null,t1), "unknown");
        TestDiagnosticProducer diag = new TestDiagnosticProducer();
        
        assertFalse ("noInferenceOnDeclared: inference should be unsuccessful", dotapp.inferTypes (Resolver.EMPTY, tpc, diag, TypeSpec.UNSPECIFIED));
        
        assertEqual ("noInferenceOnDeclared: no constraints added", tpc.getConstraints().size(), 0);
        assertEqual ("noInferenceOnDeclared: error produced", 
            diag.getErrors().toString(), 
            "[Type 'T1' does not have a definition for 'unknown']");
    }
    public void dotOnImplicitParamAddsConstraint ()
    {
        TypeParameterContext tpc = new TypeParameterContext();
        Type t1 = tpc.addImplicit();
        DotApplication dotapp = new DotApplication(new ConstVal(null,t1), "property");
        TestDiagnosticProducer diag = new TestDiagnosticProducer();
        
        assertTrue ("dotOnImplicitParamAddsConstraint: inference should be successful", 
            dotapp.inferTypes (Resolver.EMPTY, tpc, diag, TypeSpec.subtypeOf(LiteralTypes.INTLITERAL)));
        
        assertEqual ("dotOnImplicitParamAddsConstraint: constraints added", tpc.getConstraints().size(), 1);
        assertEqual (
            "dotOnImplicitParamAddsConstraint: constraint description", 
            tpc.getConstraints().get(0).getDescription(), 
            "kind::core::propertyReadable::property(_1, kind::core::IntLiteral)");
        assertEqual ("dotOnImplicitParamAddsConstraint: no error produced", diag.getErrors().size(), 0);
    }
}
