package kind.x1;

public interface Mapper<T,U> 
{
    U map (T v);
}
