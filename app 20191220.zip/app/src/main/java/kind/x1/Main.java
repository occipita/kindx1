package kind.x1;

public class Main
{
    public static void main(String [] args)
    {
        new NDFATest().run();
    }
}