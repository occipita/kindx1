package kind.x1;

public class NDFATest {
    public void run()
    {
        testUniquePath();
        testAddSecondPath();
        testRemoveStateWhenNoTransitions();
        testLazyAccept();
        testCharSet();
    }
    
    public void testUniquePath ()
    {
        NDFA sut = new NDFA(
            new int[][] {
                // state 0
                new int[] { 
                    0, 0,        // no optional behaviours
                    'a', 'a', 1  // change state to 1 when 'a' read
                },
                // state 1
                new int[] { 
                    0, 0,        // no optional behaviours
                    'b', 'b', 2  // change state to 2 when 'b' read
                },
                // state 2
                new int[] {
                    NDFA.EAGER, 1    // produce token type 1
                }
            },
            1, 0);
        sut.setInput ("ab");
        assertTrue ("testUniquePath: should have state 0 in start set", sut.hasState(0));
        assertTrue ("testUniquePath: should not have state 1 in start set", !sut.hasState(1));
        sut.step();
        assertTrue ("testUniquePath: should not have state 0 aftet step", !sut.hasState(0));
        assertTrue ("testUniquePath: should have state 1 after step", sut.hasState(1));
        assertTrue ("testUniquePath: should have produced token type 1", sut.nextToken() == 1);
        assertTrue ("testUniquePath: should have reset state after second step", sut.hasState(0) && !sut.hasState(1) && !sut.hasState(2));
    }

    public void testAddSecondPath ()
    {
        NDFA sut = new NDFA(
            new int[][] {
                // state 0
                new int[] { 
                    0, 0,        // no optional behaviours
                    'a', 'a', 1, // change state to 1 when 'a' read
                    'a', 'a', 2, // and to state 2
                },
                // state 1
                new int[] { 
                    0, 0,        // no optional behaviours
                    'b', 'b', 3  // change state to 3 when 'b' read
                },
                // state 2
                new int[] { 
                    0, 0,        // no optional behaviours
                    'c', 'c', 4  // change state to 4 when 'c' read
                },
                // state 3
                new int[] {
                    NDFA.EAGER, 1    // produce token type 1
                },
                // state 4
                new int[] {
                    NDFA.EAGER, 2    // produce token type 2
                }
            },
            2, 0);
        sut.setInput ("abac");
        sut.step();
        assertTrue ("testAddSecondPath: should not have state 0 aftet step", !sut.hasState(0));
        assertTrue ("testAddSecondPath: should have state 1 after step", sut.hasState(1));
        assertTrue ("testAddSecondPath: should have state 2 after step", sut.hasState(2));
        assertTrue ("testAddSecondPath: should produce token 1", sut.nextToken() == 1);
        assertTrue ("testAddSecondPath: should produce token 2", sut.nextToken() == 2);
    }
    public void testRemoveStateWhenNoTransitions ()
    {
        NDFA sut = new NDFA(
            new int[][] {
                // state 0
                new int[] { 
                    0, 0,        // no optional behaviours
                    'a', 'a', 1, // change state to 1 when 'a' read
                    'a', 'a', 2, // and to state 2
                },
                // state 1
                new int[] { 
                    0, 0,        // no optional behaviours
                    'a', 'a', 1  // stay in state 1 for additional 'a's
                },
                // state 2
                new int[] { 
                    0, 0,        // no optional behaviours
                    'b', 'b', 3  // change state to 3 when 'b' read
                },
                // state 3
                new int[] {
                    NDFA.EAGER, 1    // produce token type 1
                }
            },
            2, 0);
        sut.setInput ("aabc");
        sut.step(); // states 1,2
        sut.step(); // state 1
        assertTrue ("testRemoveStateWhenNoTransitions: should have state 1 after step 2", sut.hasState(1));
        assertTrue ("testRemoveStateWhenNoTransitions: should not have state 2 after step 2", !sut.hasState(2));
        assertTrue ("testRemoveStateWhenNoTransitions: should have indicated error after step 3", sut.step() == NDFA.UPDATE_ERROR);
    }

    public void testLazyAccept ()
    {
        NDFA sut = new NDFA(
            new int[][] {
                // state 0
                new int[] { 
                    0, 0,        // no optional behaviours
                    'a', 'a', 1, // change state to 1 when 'a' read
                    'a', 'a', 2, // and to state 2
                },
                // state 1
                new int[] { 
                    NDFA.LAZY, 1 // lazily produce token type 1
                },
                // state 2
                new int[] { 
                    0, 0,        // no optional behaviours
                    'b', 'b', 3  // change state to 3 when 'b' read
                },
                // state 3
                new int[] {
                    NDFA.EAGER, 2   // produce token type 2
                }
            },
            2, 0);
        sut.setInput ("aab");
        assertTrue ("testLazyAccept: should produce token 1", sut.nextToken() == 1);
        assertTrue ("testLazyAccept: should produce token 2", sut.nextToken() == 2);
    }
    
    public void testCharSet ()
    {
        NDFA sut = new NDFA(
            new int[][] {
                // state 0
                new int[] { 
                    0, 0,        // no optional behaviours
                    NDFA.LETTER, 0, 1  // change state to 1 when any letter read
                },
                // state 1
                new int[] { 
                    0, 0,        // no optional behaviours
                    NDFA.DIGIT, 0, 2  // change state to 2 when any digit read
                },
                // state 2
                new int[] { 
                    0, 0,        // no optional behaviours
                    NDFA.ANY, 0, 3  // change state to 3 when any char read
                },
                // state 3
                new int[] { 
                    0, 0,        // no optional behaviours
                    NDFA.DIGIT, 0, 2,  // change state to 2 when any digit read
                    NDFA.ANY, NDFA.DIGIT, 4  // change state to 4 when any non-digit read
                },
                // state 4
                new int[] { 
                    0, 0,        // no optional behaviours
                    NDFA.CUSTOM + 0, 0, 5  // change state to 5 on char in custom list
                },
                // state 5
                new int[] {
                    NDFA.EAGER, 1    // produce token type 1
                }
            },
            1, 0);
        sut.setCustomCharSet(0, "&^");
        sut.setInput ("a5/4,x&");
        sut.step();
        assertTrue ("testCharSet: step 1 state should be 1", sut.hasState(1));
        sut.step();
        assertTrue ("testCharSet: step 2 state should be 2", sut.hasState(2));
        sut.step();
        assertTrue ("testCharSet: step 3 state should be 3", sut.hasState(3));
        sut.step();
        assertTrue ("testCharSet: step 4 state should be 2", sut.hasState(2));
        assertTrue ("testCharSet: step 4 state should not be 4", !sut.hasState(4));
        sut.step();
        assertTrue ("testCharSet: step 5 state should be 3", sut.hasState(3));
        sut.step();
        assertTrue ("testCharSet: step 6 state should be 4", sut.hasState(4));
        assertTrue ("testCharset: should produce token 1", sut.nextToken() == 1);
    }
    
    private void assertTrue (String msg, boolean flag)
    {
        if (!flag)
            System.err.println("NDFATest: "+msg);
    }           
        
}
