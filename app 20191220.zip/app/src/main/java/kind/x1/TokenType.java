package kind.x1;

public abstract class TokenType
{
    public static final int EOF = 0;
    public static final int WS = 1;
    public static final int COMMENT = 2;
    public static final int HEXLITERAL = 3;
    public static final int BINLITERAL = 4;
    public static final int OCTLITERAL = 5;
    public static final int INTLITERAL = 6;
    public static final int FLOATLITERAL = 7;
    public static final int STRINGLITERAL = 8;
    public static final int UNDERSCORE = 9;
    public static final int ID = 10;
    public static final int MINUS = 11;
    public static final int DOUBLEPLUS = 12;
    public static final int DOUBLEMINUS = 13;
}
    
    