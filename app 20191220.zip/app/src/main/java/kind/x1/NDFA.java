package kind.x1;

import java.io.Reader;

/**
 * A simple implementation of a non-deterministic finite state automaton
 * for identification of character sequences (eg tokenization)
 * using arrays for both active state set and state transition tables.
 * Supports both eager accept states (terminating recognition as soon as they
 * are reached) and lazy accept states (terminating recognition only if no 
 * further symbols can be matched) with backtracking (although only to
 * a single recognised token). Active state set size is limited and must br
 * specified during c0nstruction. This class is intentionally simple rather
 * than flexible or efficient. For non-experimental applications, translation
 * to a deterministic FSA is recommended.
 */
public class NDFA 
{
    public static final int EAGER = 1;
    public static final int LAZY = 2;
    public static final int CHARCLASS_BASE = 1 << 16;
    public static final int LETTER = CHARCLASS_BASE;
    public static final int DIGIT = CHARCLASS_BASE + 1;
    public static final int ANY = CHARCLASS_BASE + 2;
    public static final int WS = CHARCLASS_BASE + 3;
    public static final int CUSTOM = 1 << 17;

    public static final int UPDATE_NORMAL = 0;
    public static final int UPDATE_EAGER_ACCEPT = 1;
    public static final int UPDATE_LAZY_ACCEPT = 2;
    public static final int UPDATE_NO_VALID_STATES = 3;
    public static final int UPDATE_ERROR = 4;

    
    private class StateSet
    {
        private int[] currentStates; 
        private int stateCount; 
        private int acceptState;
        
        public StateSet()
        {
            currentStates = new int[maxStates];
            currentStates[0] = initState;
            stateCount = 1;
        }
        boolean hasState(int s)
        {
            for (int i = 0; i < stateCount; i++)
                if (currentStates[i] == s) return true;
            return false;
        }
        int update (int ch)
        {
            int curStateCount = stateCount; //protect against this changing during update
            boolean [] delStates = new boolean [stateCount]; // defer deletion until after processing
            for (int i = 0; i < curStateCount; i++)
            {
                int [] map = stateMap[currentStates[i]];
                boolean found = false;
                for (int j = 2; j < map.length; j += 3)
                    if ((map[j] <= ch && map[j+1] >= ch) || 
                        (map[j] >= CHARCLASS_BASE && classMatch (map[j], map[j+1], ch)))
                    {
                        int newState = map[j+2];
                        int s = found ? stateCount++ : i;
                        currentStates[s] = newState;
                        found = true;
                        
                        if ((stateMap[newState][0] & EAGER) == EAGER) 
                        {
                            acceptState = newState;
                            return UPDATE_EAGER_ACCEPT;
                        }
                    }
                if (!found) delStates[i] = true;
            }
            
            int d = 0;
            boolean lazyAccept = false;
            for (int s = 0; s < stateCount; s++)
            {
                if (s >= curStateCount || !delStates[s])
                {
                    currentStates[d++] = currentStates[s];
                    if ((stateMap[currentStates[s]][0] & LAZY) == LAZY) 
                    {
                        acceptState = currentStates[s];
                        lazyAccept = true;
                    }
                }
            }
            stateCount = d;
            
            if (lazyAccept)
                return UPDATE_LAZY_ACCEPT;
            if (stateCount == 0)
                return UPDATE_NO_VALID_STATES;
            return UPDATE_NORMAL;
        }  
        public String statestr() 
        {
            StringBuilder r = new StringBuilder();
            String s = "";
            for (int i = 0; i < stateCount; i++)
            {
                r.append(s).append(currentStates[i]);
                s = ", ";
            }
            return r.toString();
        }
    }
    public interface CharSupplier
    {
        /** return the next character, or -1 to indicate completion */
        public int next() throws Exception;
    }   
    
    private final int[][] stateMap;
    private final int maxStates, initState;
    private StateSet current, backtrack;
    private CharSupplier input;
    private int lastAcceptedToken = -1; 
    private String [] customCharSets = new String[32];
    
    public NDFA(int[][] stateMap, int maxStates, int initState)
    {
        this.stateMap = stateMap;
        this.maxStates = maxStates;
        this.initState = initState;
        reset();
    }
    
    public void setCustomCharSet (int index, String chars)
    {
        customCharSets[index] = chars;
    }
    
    public void reset ()
    {
        current = new StateSet ();
        backtrack = null;
    }
    
    public void setInput (CharSupplier input)
    {
        this.input = input;
    }
    
    public void setInput (final Reader r)
    {
        setInput (new CharSupplier() {
            public int next () throws Exception
            {
                return r.read();
            }
        });
    }
    
    public void setInput (final CharSequence cs)
    {
        setInput (new CharSupplier() {
            int i = 0;
            public int next()
            {
                if (i < cs.length())
                    return cs.charAt(i++);
                else
                    return -1;
            }
        });
    }
    public String statestr()
    {
        if (backtrack == null)
            return current.statestr();
        else
            return current.statestr() + " (or " + backtrack.statestr() + " with token " + stateMap[current.acceptState][1] +")";
    }
    public int step()
    {
        try
        {
            int ch = input.next();
            if (backtrack != null)
            {
                int r = backtrack.update(ch);
                if (r == UPDATE_NO_VALID_STATES)
                    backtrack = null;
                if (r == UPDATE_EAGER_ACCEPT)
                    System.err.println("eager accept backtrack " + statestr());
            }
            switch (current.update(ch))
            {
            case UPDATE_NORMAL:
                System.out.println("read '"+(char)ch+"', states="+statestr());
                return UPDATE_NORMAL;

            case UPDATE_LAZY_ACCEPT:
                backtrack = new StateSet();
                System.out.println("read '"+(char)ch+"', states="+statestr()+" -- LAZY ACCEPT");
                return UPDATE_NORMAL;
                
            case UPDATE_EAGER_ACCEPT:
                lastAcceptedToken = stateMap[current.acceptState][1];
                System.out.println("read '"+(char)ch+"', states="+statestr()+" -- ACCEPT "+lastAcceptedToken);
                reset();
                return UPDATE_EAGER_ACCEPT;
                
            case UPDATE_NO_VALID_STATES:
                if (backtrack != null)
                {
                    lastAcceptedToken = stateMap[current.acceptState][1];
                    current = backtrack;
                    backtrack = null;
                    System.out.println("read '"+(char)ch+"', states="+statestr()+" -- EMIT LAZY TOKEN "+lastAcceptedToken);
                    return UPDATE_LAZY_ACCEPT;
                }
            default:
                System.out.println("read '"+(char)ch+"', states="+statestr()+" -- ERROR");
                return UPDATE_ERROR;    
            }
        }
        catch (Exception e)
        {
            // FIXME report error
            return UPDATE_ERROR;
        } 
    }
    public int nextToken()
    {
        while (step() == UPDATE_NORMAL)
            ;
            
        return lastAcceptedToken;
    }
    public boolean hasState(int state)
    {
        return current.hasState(state);
    }
    private final boolean classMatch (int classInclude, int classExclude, int ch)
    {
        return classMatch (classInclude, ch) && (classExclude == 0 || !classMatch (classExclude, ch));
    }
    private final boolean classMatch (int classId, int ch)
    {
        if (ch < 0) return false;
        if (classId >= CUSTOM) return customCharSets[classId - CUSTOM].indexOf((char)ch) >= 0;
        switch (classId)
        {
            case LETTER: return Character.isLetter(ch);   
            case DIGIT: return Character.isDigit(ch);
            case ANY: return true;
            case WS: return Character.isWhitespace(ch);
            default: return false;
        }
    }
}
