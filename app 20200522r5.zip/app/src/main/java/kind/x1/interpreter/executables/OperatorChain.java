package kind.x1.interpreter.executables;

import java.util.List;
import java.util.ArrayList;
import kind.x1.interpreter.types.*;
import kind.x1.interpreter.values.KVal;
import kind.x1.interpreter.*;
import kind.x1.*;


public class OperatorChain implements Evaluatable 
{
    public static class Operator
    {
        private String name;
        
        public Operator(String n) { name = n; }
        public String getName() { return name; }
    }
    private List<Evaluatable> operands = new ArrayList<>();
    private List<Operator> operators = new ArrayList<>();
    private boolean rightAssoc;
    
    public OperatorChain (boolean rightAssoc)
    {
        this.rightAssoc = rightAssoc;
    }
    
    public List<Evaluatable> getOperands() { return operands; }
    public List<Operator> getOperators() { return operators; }
    public boolean isRightAssoc () { return rightAssoc; }      
    
    public boolean inferTypesSilently (Resolver resolver, TypeSpec target) { return false; }
    public boolean inferTypes (Resolver resolver, TypeParameterContext context, DiagnosticProducer diag, TypeSpec expected) { return true; }
    public boolean checkTypes (DiagnosticProducer diag) { return false; }

    public Optional<Type> getResultType () { return Optional.empty(); }

}
