package kind.x1.interpreter.executables;

import kind.x1.interpreter.types.*;
import kind.x1.interpreter.values.KVal;
import kind.x1.interpreter.*;
import kind.x1.*;

public class ConstVal implements Evaluatable
{
    private final KVal value;
    private final Type type;
    
    public ConstVal (KVal v, Type t) { value = v; type = t; }
    public KVal getValue() { return value; }
    public Type getType () { return type; }
    
    public boolean inferTypesSilently (Resolver resolver, TypeSpec target) { return true; }
    public boolean inferTypes (Resolver resolver, TypeParameterContext context, DiagnosticProducer diag, TypeSpec expected) { return expected.matches(type); }
    public boolean checkTypes (DiagnosticProducer diag) { return true; }
    
    public Optional<Type> getResultType () { return Optional.of(type); }
    
    
}
