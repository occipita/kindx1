package kind.x1.interpreter.types;

/** 
 * Describes the expected type of an expression being type checked.
 * Expected types may be unspecified, specified exactly, required to be
 * a subtype of a given typr, or required to be a supertype of a given type.
 */
public class TypeSpec 
{
    public enum Mode { 
        UNSPECIFIED { boolean matches (Type p, Type t) { return true; } }, 
        EXACT       { boolean matches (Type p, Type t) { return t.equals(p); } }, 
        SUBTYPE     { boolean matches (Type p, Type t) { return false; /* FIXME */ } }, 
        SUPERTYPE   { boolean matches (Type p, Type t) { return false; /* FIXME */ } };
        
        abstract boolean matches (Type p, Type t); 
    } 
    
    private Mode mode;
    private Type type; // may be null iff mode == UNSPECIFIED
    
    private TypeSpec (Mode m, Type t) { mode = m; type = t; }
    
    public boolean matches (Type t) { return mode.matches (type, t); }
    
    public Mode getMode() { return mode; }
    public Type getType() { return type; } 
    
    public static TypeSpec UNSPECIFIED = new TypeSpec(Mode.UNSPECIFIED, null);
    public static TypeSpec exactly(Type t) { return new TypeSpec(Mode.EXACT, t); }
    public static TypeSpec subtypeOf(Type t) { return new TypeSpec(Mode.SUBTYPE, t); }
    public static TypeSpec supertypeOf(Type t) { return new TypeSpec(Mode.SUPERTYPE, t); }
}
